﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    internal class Qstn8
    {
        public double calculate(int s)
        {
            return Math.Pow(2,s);
        }
    }
}
